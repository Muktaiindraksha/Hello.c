#include <stdio.h>
int main(){
	int a,volume;
	printf("enter a number:---");
	scanf("%d",&a);
	volume=a*a*a;
	printf("volume of a cube is:%d",volume);
	
	return 0;
}
