#include <stdio.h>
int main() {
	int l,b,a,p;
	printf("enter a number:--");
	scanf("%d %d",&a,&b);
	a=(l*b);
	p=2(l*b);
	if (a>p)
	printf("Area is greater %d",a);
	else
	printf("Perimeter is greater%d",p);
	return 0;
	
}
