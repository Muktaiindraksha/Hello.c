#include <stdio.h>
int main() {
	int m,n;
	printf("enter a number:--");
	scanf("%d %d",&m,&n);
	if (n>=5)
	printf("Net bonus Amount");
	else
	printf("amount is:%d",m*5/100);
	
	return 0;
}
