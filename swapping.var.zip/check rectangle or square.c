#include <stdio.h>
int main() {
	int a,b;
	printf("enter a side:--");
	scanf("%d %d",&a,&b);
	if (a==b)
	printf("Rectangle");
	else
	printf("square");
	return 0;
	
}
