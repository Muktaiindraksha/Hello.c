#include <stdio.h> 
int main() {
	int v,s,a,b;
	printf("enter a number:--");
	scanf("%d%d",&a,&b);
	a=v*15;
	b=s*12;
	printf("the total bill is:%d",a,b);
	
	return 0;
}
