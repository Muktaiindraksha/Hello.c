#include <stdio.h>
int main(){
	int n,f,i;
	printf("Enter a number:--");
	scanf("%d",&n);
	f=i/12;
	if (f>=0 || f>=5)
	printf("ALLOWED");
	else
	printf("NOT ALLOWED");
	return 0;
} 

