#include <stdio.h>
int main() {
	int a,b,c;
	printf("enter a number:--");
	scanf("%d %d",&a,&b);
	c=a+b;
	if (c>15 || c>20)
	printf("20");
	else
	printf("NOT");
	return 0;
	
}
