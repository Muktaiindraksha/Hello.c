#include <stdio.h>
int main () {
    int n,s; 
    printf("Enter a number");
    scanf("%d %c");
    if n<="s"
      print("YES");
    else
      print("NO");
}
