#include <stdio.h>
int main() {
	
    float radius, dia,circum;
    printf("Enter radius of circle: ");
    scanf("%d", &radius,&dia);
    circum=2*3.14*radius;
    printf("Diameter of the circle = 2.f% units\n", dia);
    return 0;
}
