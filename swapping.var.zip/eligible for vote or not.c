#include <stdio.h>
int main(){
	int n;
	printf("Enter a number:---");
	scanf("%d",&n);
	if (n>18)
	printf("Eligible");
	else
	printf("NOT Eligible");
	return 0;
}
