#include <stdio.h> 
int main() {
	int n,m;
	printf("enter a number:--");
	scanf("%d",&n);
	m=n%10;
	printf("the last digit no is:%d",m);
	
	return 0;
}



