int a=1.9999 
# include <stdio.h> 
int main () {
	int a=1.9999;
	print("%d \n",a);
	return 0;
}
