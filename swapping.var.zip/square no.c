#include <stdio.h>
int main() {
	int s,n;
	printf("enter a number:--");
	scanf("%d",&n);
	s=n*n;
	printf("the square of no is:%d",s);
	
	return 0;
}

