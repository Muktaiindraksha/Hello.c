#include <stdio.h>
int main() {
	int n;
	printf("enter a number:--");
	scanf("%d",&n);
	if (n<=999)
	printf("it is a 3 digit no");
	else
	printf("NOT");
	return 0;
	
}
