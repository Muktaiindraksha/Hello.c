#include <stdio.h>
int main() {
    int num,num1,sum;
    printf("enter two number");
    scanf("%d %d", &num,&num1);
    sum=num+num1;
	printf("%d+%d=%d",num,num1,sum);
	
	return 0;
	
}
