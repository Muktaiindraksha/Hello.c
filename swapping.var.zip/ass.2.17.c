#include <stdio.h>
int main() {
	int age;
	printf("enter a number:--");
	scanf("%d",&age);
	if (age>=60)
	printf("Cinear citizen");
	else
	printf("NOT Cinear citizen");
	return 0;
	
}
