# include  <stdio.h> 
//area of circle 
int main() {
	float radius;
	printf("enter a radius");
	scanf("%f",&radius);
	
	printf("area is:%f",3.14*radius*radius);
	return 0;
}
