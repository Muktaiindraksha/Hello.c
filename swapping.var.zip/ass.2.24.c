#include <stdio.h>
int main() {
	int a,b;
	printf("enter a number:--");
	scanf("%d %d",&a,&b);
	if (a>b)
	printf("the num is %d",a-b);
	else
	printf("the num is %d",a+b);
	return 0;
	
}
