#include <stdio.h>
int main() {
	int n;
	printf("enter a number:--");
	scanf("%d",&n);
	if (n==1000)
	printf("The number is smallest 4 digit no");
	else
	printf("The number is not smallest 4 digit no");
	return 0;
	
}
