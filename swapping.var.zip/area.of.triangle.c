#include <stdio.h>  
int main() {
	float b,h,area;
	printf("enter a base and height");
	scanf("%f %f",&b,&h);
	area=b*h;
	printf("area of triangle is:%.2f",area );
	
	return 0;
	
}
