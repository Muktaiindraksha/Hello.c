#include <stdio.h>
int main() {
	int n,i;
	printf("enter a number:--");
	scanf("%d",&n);
	if (n%4==0)
	printf("the increment is %d",i++);
	else
	printf("the decrement is %d",i--);
	return 0;
	
}
