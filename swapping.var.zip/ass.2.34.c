#include <stdio.h>
int main(){
	int n;
	printf("Enter a number:--");
	scanf("%d",&n);
	if (n%5==0)
	printf("Group Leader");
	else
	printf("NOT group leader");
	return 0;
}
