#include <stdio.h>
int main (){
	char n;
	printf("enter a CITY:--");
	scanf("%c",&n);
	if (n=='d')
	printf("RED FORT");
	else if (n=='a')
	printf("TAJ-MAHAL");
	else if (n=='j')
	printf("PINK CITY");
	else
	printf("INVALID");
	return 0;
}
