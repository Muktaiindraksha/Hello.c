#include <stdio.h>
int main(){
	int c,n;
	printf("enter a number:--");
	scanf("%d",&n);
	c=n*n*n;
	printf("the cube of number is:%d",c);
	return 0;
}
