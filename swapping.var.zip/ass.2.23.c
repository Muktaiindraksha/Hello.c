#include <stdio.h>
int main() {
	int n;
	printf("enter a number:--");
	scanf("%d",&n);
	if (n%10==3)
	printf("it ends with 3");
	else
	printf("it ends with 7");
	return 0;
	
}
