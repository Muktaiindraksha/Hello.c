#include <stdio.h>
int main() {
	float i;
	for (i=1.0; i<=10.0; i=i+1) {
		printf("%f \n",i);
	}
}
