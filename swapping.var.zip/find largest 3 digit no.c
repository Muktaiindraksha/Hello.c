#include <stdio.h>
int main() {
	int n;
	printf("enter a number:--");
	scanf("%d",&n);
	if (n==999)
	printf("The number is largest 3 digit no..");
	else
	printf("The number is not largest 3 digit no..");
	return 0;
	
}
