//area of square 
#include <stdio.h>
int main() {
    float side;
	printf("enter a side");
	scanf("%f",&side);
	
	printf("area of square is: %f ",side*side);
	return 0;
} 

