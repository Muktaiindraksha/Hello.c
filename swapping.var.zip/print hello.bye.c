#include <stdio.h>
int main(){
	int n;
	printf("Enter a number:---");
	scanf("%d",&n);
	if (n%5==0)
	printf("HELLO");
	else
	printf("BYE");
	return 0;
}
