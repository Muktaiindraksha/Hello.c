#include <stdio.h>
int main(){
	char ch;
	for (ch='a';ch<='z';ch=ch+1) {
		printf("%c \n",ch);
	}
	return 0;
}
