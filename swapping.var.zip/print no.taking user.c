#include <stdio.h>
int main() {
	int n;
	printf("enter a number:--");
	scanf("%d",&n);
	
	int i=0;
	while (i<=n) {
	printf("%d \n",i);
	i=i+1;
   } 
   return 0;
}
