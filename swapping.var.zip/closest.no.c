#include <stdio.h>
int main() {
	int a,b,p,q;
	printf("enter a number:--");
	scanf("%d%d",&p,&q);
	p=a/b;
	q=p*b;
	printf("the number is:%d",p,q);
	return 0;
	
}
