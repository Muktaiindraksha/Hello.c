#include<stdio.h>
int main()
{
    int side,perimeter;
    printf("enter side of square: ");
    scanf("%d",&side);
     
  
    perimeter=4*side;
    printf("Perimeter Of Square: %d\n",perimeter);
    return 0;
}
