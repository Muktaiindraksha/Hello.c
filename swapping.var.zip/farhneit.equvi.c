#include <stdio.h>
int main(){
	int f,c;
	printf("enter a number:--");
	scanf("%d",&c);
	c= (f-32)*5/9;
	printf("\n Temperature in Celsius is : %d",c);
	return 0;
	
}

