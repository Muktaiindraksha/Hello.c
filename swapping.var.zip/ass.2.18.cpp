#include <stdio.h>
int main() {
	int temp;
	printf("enter a number:--");
	scanf("%d",&temp);
	if (temp>=100)
	printf("Water is boiling..");
	else
	printf("NOT boiling");
	return 0;
	
}
