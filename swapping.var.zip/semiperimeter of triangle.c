#include <stdio.h> 
int main () {
	int a,b,c,semiperimeter;
	printf("enter a sides:--");
	scanf("%d %d %d",&a,&b,&c);
	semiperimeter=(a+b+c)/2;
	printf("semiperimeter of triangle is:%d",semiperimeter);
	
	return 0;
	
}

