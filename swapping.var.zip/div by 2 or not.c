# include <stdio.h>
# include <math.h> 

int main() {
	int x;
	printf("enter a no");
	scanf("%d",& x); 
	printf("%d",x%2==0);
	return 0;
}


