#include <stdio.h>
int main() {
	int x,y,z;
	printf("enter the number");
	scanf("%d %d",&x,&y);
	z=x%y;
	printf("the books we can buy is:%d",z);
	
	return 0;
}
