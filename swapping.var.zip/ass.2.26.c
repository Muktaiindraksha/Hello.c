#include <stdio.h>
int main() {
	int a,b,c;
	printf("enter a number:--");
	scanf("%d %d",&a,&b);
	if (c="+")
	printf("the sum is %d",a+b);
	else
	printf("the substraction is %d",a-b);
	return 0;
	
}
