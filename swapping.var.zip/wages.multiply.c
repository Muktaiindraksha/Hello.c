#include <stdio.h>
int main() {
	int num,num1,multi;
	printf("enter a number:--");
	scanf("%d",&num,&num1);
	multi=num*num1;
	printf("%d*%d=%d",num,num1,multi);
	
	return 0;
} 


