int main()
{
	
	int length,breadth,height,volume;
	printf("enter length :-- ");
	scanf("%d",&length);
	printf("enter breadth :-- ");
	scanf("%d",&breadth);
	printf("enter height :-- ");
	scanf("%d",&height);
	volume=length*breadth*height;
	printf("Volume Of Cuboid:- %d \n",volume);
	return 0;
}


