#include <stdio.h>
int main () {
	int sp,m,d;
	printf("enter a no:--");
	scanf("%d %d",&m,&d);
	sp=m+d;
	printf("the s.p of product:%d",sp);
	
	return 0;
	
}
